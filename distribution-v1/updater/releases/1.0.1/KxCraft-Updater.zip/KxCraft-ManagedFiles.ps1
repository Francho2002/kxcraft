Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-KxManagedFileState([string]$MinecraftDirectory, [string]$PackTomlUrl) {
    $root = [IO.Path]::GetFullPath($MinecraftDirectory)
    $statePath = Join-Path $root '.kxcraft-packwiz-state.json'
    $files = @{}
    if (!(Test-Path -LiteralPath $statePath)) {
        return [pscustomobject]@{ Path = $statePath; Files = $files }
    }
    if (!(Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'KxCraft managed-file state is not a regular file; refusing Packwiz update.' }
    $stateItem = Get-Item -LiteralPath $statePath -Force
    if (($stateItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'KxCraft managed-file state is a reparse point; refusing Packwiz update.' }

    try { $state = Get-Content -LiteralPath $statePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop }
    catch { throw "KxCraft managed-file state cannot be read; refusing Packwiz update: $($_.Exception.Message)" }
    if ($state.schemaVersion -ne 1 -or [string]$state.packTomlUrl -ne $PackTomlUrl) {
        throw 'KxCraft managed-file state is incompatible with this Packwiz URL; preserving it and blocking launch.'
    }
    foreach ($entry in $state.files) {
        $relative = [string]$entry.path
        $hash = [string]$entry.sha256
        Test-KxManagedRelativePath $relative
        if ($hash -notmatch '^[0-9a-f]{64}$' -or $files.ContainsKey($relative)) {
            throw 'KxCraft managed-file state contains a malformed or duplicate hash record.'
        }
        $files[$relative] = $hash
    }
    return [pscustomobject]@{ Path = $statePath; Files = $files }
}

function Test-KxManagedRelativePath([string]$RelativePath) {
    if ([string]::IsNullOrWhiteSpace($RelativePath) -or $RelativePath.Contains('\') -or
        [IO.Path]::IsPathRooted($RelativePath) -or $RelativePath -match '(^|/)\.\.(/|$)' -or
        $RelativePath -notmatch '^(mods|resourcepacks|shaderpacks)/[^/]+(?:/[^/]+)*$') {
        throw "Unsafe managed file path: $RelativePath"
    }
    if ($RelativePath.StartsWith('mods/', [StringComparison]::Ordinal) -and $RelativePath -notmatch '^mods/[^/]+\.jar$') {
        throw "Only direct client mod JARs can be retired automatically: $RelativePath"
    }
}

function Get-KxManagedFileSha256([string]$Path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Get-KxPackwizCachedModState([string]$MinecraftDirectory) {
    $root = [IO.Path]::GetFullPath($MinecraftDirectory)
    $cachePath = Join-Path $root 'packwiz.json'
    $files = @{}
    if (!(Test-Path -LiteralPath $cachePath -PathType Leaf)) { return $files }

    $cacheItem = Get-Item -LiteralPath $cachePath -Force
    if (($cacheItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'Packwiz cache is a reparse point; refusing to trust file ownership before update.'
    }
    try { $cache = Get-Content -LiteralPath $cachePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop }
    catch { throw "Could not read Packwiz cached-file ownership before update: $($_.Exception.Message)" }
    if ($null -eq $cache.cachedFiles) { throw 'Packwiz cache has no cachedFiles registry; refusing to update without file ownership evidence.' }

    foreach ($entryProperty in $cache.cachedFiles.PSObject.Properties) {
        $entry = $entryProperty.Value
        $relative = [string]$entry.cachedLocation
        if (!$relative.StartsWith('mods/', [StringComparison]::OrdinalIgnoreCase)) { continue }
        Test-KxManagedRelativePath $relative
        if ($relative -notmatch '^mods/[^/]+\.jar$') { throw "Packwiz cache contains an unsafe managed mod path: $relative" }

        $hashType = [string]$entry.linkedFileHash.type
        $hash = [string]$entry.linkedFileHash.value
        if ($hashType -cne 'sha256' -or $hash -notmatch '^[0-9a-fA-F]{64}$') {
            throw "Packwiz cache lacks a valid linked-file SHA-256 for $relative; refusing update."
        }
        $hash = $hash.ToLowerInvariant()
        if ($files.ContainsKey($relative) -and $files[$relative] -cne $hash) {
            throw "Packwiz cache contains conflicting ownership hashes for $relative."
        }
        $files[$relative] = $hash
    }
    return $files
}

function Assert-KxManagedModsBeforePackwiz([string]$MinecraftDirectory, [string]$PackTomlUrl, [hashtable]$CurrentFiles) {
    $root = [IO.Path]::GetFullPath($MinecraftDirectory)
    $modsRoot = Join-Path $root 'mods'
    if (Test-Path -LiteralPath $modsRoot) {
        if (!(Test-Path -LiteralPath $modsRoot -PathType Container)) { throw 'The mods path is not a directory; refusing Packwiz update.' }
        $modsItem = Get-Item -LiteralPath $modsRoot -Force
        if (($modsItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'The mods directory is a symbolic link or junction; refusing Packwiz update.'
        }
    }

    $previous = Get-KxManagedFileState $root $PackTomlUrl
    $packwizPrevious = Get-KxPackwizCachedModState $root
    $allPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)

    foreach ($relative in @($previous.Files.Keys)) {
        if ([string]$relative -match '^mods/[^/]+\.jar$') { [void]$allPaths.Add([string]$relative) }
    }
    foreach ($relative in @($packwizPrevious.Keys)) { [void]$allPaths.Add([string]$relative) }
    foreach ($relative in @($CurrentFiles.Keys)) {
        Test-KxManagedRelativePath ([string]$relative)
        if ([string]$relative -notmatch '^mods/[^/]+\.jar$') { throw "Only direct mod JARs can be preflighted before Packwiz: $relative" }
        if ([string]$CurrentFiles[$relative] -notmatch '^[0-9a-f]{64}$') { throw "Invalid current managed SHA-256: $relative" }
        [void]$allPaths.Add([string]$relative)
    }

    foreach ($relative in $allPaths) {
        $path = Join-Path $root ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        if (!(Test-Path -LiteralPath $path)) { continue }
        if (!(Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "A non-file occupies managed mod path '$relative'; preserving it and blocking Packwiz before it can change files."
        }
        $item = Get-Item -LiteralPath $path -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "A reparse point occupies managed mod path '$relative'; preserving it and blocking Packwiz before it can change files."
        }
        try { $actualHash = Get-KxManagedFileSha256 $path }
        catch { throw "Could not verify '$relative' before Packwiz; preserving it and blocking update. Details: $($_.Exception.Message)" }

        $knownHashes = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        if ($previous.Files.ContainsKey($relative)) { [void]$knownHashes.Add([string]$previous.Files[$relative]) }
        if ($packwizPrevious.ContainsKey($relative)) { [void]$knownHashes.Add([string]$packwizPrevious[$relative]) }
        $hasCurrent = $CurrentFiles.ContainsKey($relative)
        if ($hasCurrent) { [void]$knownHashes.Add([string]$CurrentFiles[$relative]) }

        if (!$knownHashes.Contains($actualHash)) {
            if ($hasCurrent -and !$previous.Files.ContainsKey($relative) -and !$packwizPrevious.ContainsKey($relative)) {
                throw "Unmanaged or personal JAR collides with the KxCraft target '$relative'; preserving it and blocking Packwiz."
            }
            throw "Managed JAR '$relative' was modified since its last verified version; preserving it and blocking Packwiz before overwrite or removal."
        }
    }
}

function Update-KxManagedFileState([string]$MinecraftDirectory, [string]$PackTomlUrl, [hashtable]$CurrentFiles) {
    $root = [IO.Path]::GetFullPath($MinecraftDirectory)
    $previous = Get-KxManagedFileState $root $PackTomlUrl
    foreach ($relative in $CurrentFiles.Keys) {
        Test-KxManagedRelativePath ([string]$relative)
        if ([string]$CurrentFiles[$relative] -notmatch '^[0-9a-f]{64}$') { throw "Invalid new managed SHA-256: $relative" }
    }

    foreach ($relative in @($previous.Files.Keys)) {
        if ($CurrentFiles.ContainsKey($relative)) { continue }
        $path = Join-Path $root ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        if (!(Test-Path -LiteralPath $path)) { continue }
        if (!(Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Obsolete managed path is occupied by a non-file; preserving its ownership record and blocking launch: $relative"
        }
        $attributes = [IO.File]::GetAttributes($path)
        if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Obsolete managed path is a reparse point; preserving its ownership record and blocking launch: $relative"
        }
        try { $actualHash = Get-KxManagedFileSha256 $path }
        catch {
            $detail = $_.Exception.Message
            throw "Could not verify obsolete managed file '$relative'; its prior ownership record is preserved and launch is blocked so the next attempt can retry. Close any process holding it. Details: $detail"
        }
        if ($actualHash -ne [string]$previous.Files[$relative]) {
            throw "Obsolete managed file was locally changed; preserving it and blocking launch: $relative"
        }
        try {
            Remove-Item -LiteralPath $path -Force -ErrorAction Stop
            if (Test-Path -LiteralPath $path) { throw 'The file still exists after Remove-Item returned.' }
        } catch {
            $detail = $_.Exception.Message
            throw "Could not remove obsolete managed file '$relative'; its prior ownership record is preserved so the next launch can retry. Close any process holding it. Details: $detail"
        }
    }

    $entries = [Collections.Generic.List[object]]::new()
    foreach ($relative in @($CurrentFiles.Keys | Sort-Object)) {
        $entries.Add([ordered]@{ path = [string]$relative; sha256 = [string]$CurrentFiles[$relative] })
    }
    $state = [ordered]@{ schemaVersion = 1; packTomlUrl = $PackTomlUrl; files = @($entries) }
    $json = (ConvertTo-Json -InputObject $state -Depth 8) + "`n"
    $tempPath = $previous.Path + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($tempPath, $json, [Text.UTF8Encoding]::new($false))
        if (Test-Path -LiteralPath $previous.Path -PathType Leaf) {
            $backupPath = $tempPath + '.bak'
            [IO.File]::Replace($tempPath, $previous.Path, $backupPath)
            [IO.File]::Delete($backupPath)
        } else {
            [IO.File]::Move($tempPath, $previous.Path)
        }
    } finally {
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) { Remove-Item -LiteralPath $tempPath -Force }
    }
}
