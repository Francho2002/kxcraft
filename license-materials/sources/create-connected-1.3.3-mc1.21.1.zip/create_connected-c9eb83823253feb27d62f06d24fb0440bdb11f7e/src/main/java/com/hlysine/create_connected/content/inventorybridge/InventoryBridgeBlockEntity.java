package com.hlysine.create_connected.content.inventorybridge;

import com.hlysine.create_connected.registries.CCBlockEntityTypes;
import com.hlysine.create_connected.CreateConnected;
import com.hlysine.create_connected.content.inventoryaccessport.WrappedItemHandler;
import com.simibubi.create.api.packager.InventoryIdentifier;
import com.simibubi.create.content.logistics.packager.IdentifiedInventory;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.SidedFilteringBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.inventory.CapManipulationBehaviourBase;
import com.simibubi.create.foundation.blockEntity.behaviour.inventory.InvManipulationBehaviour;
import net.createmod.catnip.math.BlockFace;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.items.IItemHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

import static com.hlysine.create_connected.content.inventorybridge.InventoryBridgeBlock.ATTACHED_NEGATIVE;
import static com.hlysine.create_connected.content.inventorybridge.InventoryBridgeBlock.ATTACHED_POSITIVE;

@EventBusSubscriber(modid = CreateConnected.MODID)
public class InventoryBridgeBlockEntity extends SmartBlockEntity {
    protected IItemHandler itemCapability;
    private InvManipulationBehaviour negativeInventory;
    private InvManipulationBehaviour positiveInventory;

    SidedFilteringBehaviour filters;
    public FilteringBehaviour negativeFilter;
    public FilteringBehaviour positiveFilter;

    private boolean powered;

    private IItemHandler cachedNegativeHandler;
    private IItemHandler cachedPositiveHandler;
    private boolean negativeHandlerDirty = true;
    private boolean positiveHandlerDirty = true;

    public InventoryBridgeBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);

        itemCapability = null;
        powered = false;
    }

    @Override
    public void initialize() {
        super.initialize();
        updateConnectedInventory();
    }

    @SubscribeEvent
    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.ItemHandler.BLOCK,
                CCBlockEntityTypes.INVENTORY_BRIDGE.get(),
                (be, context) -> {
                    if (be.itemCapability == null)
                        be.refreshCapability();
                    return be.itemCapability;
                }
        );
    }

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
        CapManipulationBehaviourBase.InterfaceProvider towardBlockFacing1 =
                (w, p, s) -> new BlockFace(p, InventoryBridgeBlock.getNegativeTarget(s));
        CapManipulationBehaviourBase.InterfaceProvider towardBlockFacing2 =
                (w, p, s) -> new BlockFace(p, InventoryBridgeBlock.getPositiveTarget(s));
        behaviours.add(negativeInventory = new InvManipulationBehaviour(this, towardBlockFacing1));
        behaviours.add(positiveInventory = new InvManipulationBehaviour(this, towardBlockFacing2));
        behaviours.add(filters = new SidedFilteringBehaviour(
                this,
                new InventoryBridgeFilterSlot(),
                (facing, filter) -> {
                    if (facing.getAxisDirection() == Direction.AxisDirection.NEGATIVE) {
                        negativeFilter = filter;
                    } else {
                        positiveFilter = filter;
                    }
                    return filter;
                },
                facing -> facing.getAxis() == getBlockState().getValue(InventoryBridgeBlock.AXIS)
        ));
    }

    public boolean isAttachedNegative() {
        return !powered && negativeInventory.hasInventory() && !(negativeInventory.getInventory() instanceof WrappedItemHandler);
    }

    public boolean isAttachedPositive() {
        return !powered && positiveInventory.hasInventory() && !(positiveInventory.getInventory() instanceof WrappedItemHandler);
    }

    public @Nullable BlockState getNegativeAttachedBlock() {
        if (!isAttachedNegative()) return null;
        return level.getBlockState(negativeInventory.getTarget().getConnectedPos());
    }

    public @Nullable BlockState getPositiveAttachedBlock() {
        if (!isAttachedPositive()) return null;
        return level.getBlockState(positiveInventory.getTarget().getConnectedPos());
    }

    public void updateConnectedInventory() {
        negativeInventory.findNewCapability();
        positiveInventory.findNewCapability();
        negativeHandlerDirty = true;
        positiveHandlerDirty = true;
        boolean previouslyPowered = powered;
        powered = level.hasNeighborSignal(worldPosition);
        if (powered != previouslyPowered) {
            notifyUpdate();
        }
        boolean attachedNegative = isAttachedNegative();
        boolean attachedPositive = isAttachedPositive();
        if (attachedNegative != getBlockState().getValue(ATTACHED_NEGATIVE) || attachedPositive != getBlockState().getValue(ATTACHED_POSITIVE)) {
            BlockState state = getBlockState()
                    .setValue(ATTACHED_NEGATIVE, attachedNegative)
                    .setValue(ATTACHED_POSITIVE, attachedPositive);
            level.setBlockAndUpdate(worldPosition, state);
        }
    }

    @Nullable
    public InventoryIdentifier getInventoryId() {
        // best we can do is identify as one of the two connected inventory
        // not currently possible to completely dedupe inventory contents in stock networks
        IdentifiedInventory inv = negativeInventory.getIdentifiedInventory();
        return inv == null ? null : inv.identifier();
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        powered = tag.getBoolean("Powered");
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.putBoolean("Powered", powered);
    }

    private IItemHandler getNegativeHandler() {
        if (powered) return null;
        if (negativeHandlerDirty) {
            IItemHandler h = negativeInventory.getInventory();
            cachedNegativeHandler = (h instanceof WrappedItemHandler) ? null : h;
            negativeHandlerDirty = false;
        }
        return cachedNegativeHandler;
    }

    private IItemHandler getPositiveHandler() {
        if (powered) return null;
        if (positiveHandlerDirty) {
            IItemHandler h = positiveInventory.getInventory();
            cachedPositiveHandler = (h instanceof WrappedItemHandler) ? null : h;
            positiveHandlerDirty = false;
        }
        return cachedPositiveHandler;
    }

    private void refreshCapability() {
        itemCapability = new InventoryBridgeHandler();
        invalidateCapabilities();
    }

    private class InventoryBridgeHandler implements WrappedItemHandler {

        private static boolean inRecursion = false;

        private <T> T preventRecursion(Supplier<T> value, T defaultValue) {
            if (inRecursion) return defaultValue;
            inRecursion = true;
            try {
                return value.get();
            } finally {
                inRecursion = false;
            }
        }

        @Override
        public int getSlots() {
            return preventRecursion(() -> {
                IItemHandler handler1 = getNegativeHandler();
                IItemHandler handler2 = getPositiveHandler();
                if (handler1 == null && handler2 == null) {
                    return 0;
                } else if (handler1 == null) {
                    return handler2.getSlots();
                } else if (handler2 == null) {
                    return handler1.getSlots();
                } else {
                    return handler1.getSlots() + handler2.getSlots();
                }
            }, 0);
        }

        @Override
        public @NotNull ItemStack getStackInSlot(int slot) {
            return preventRecursion(() -> {
                IItemHandler handler1 = getNegativeHandler();
                IItemHandler handler2 = getPositiveHandler();
                if (handler1 == null && handler2 == null) {
                    return ItemStack.EMPTY;
                } else if (handler1 == null) {
                    ItemStack stack = handler2.getStackInSlot(slot);
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!positive) return ItemStack.EMPTY;
                    if (negative && !negativeFilter.getFilter().isEmpty() && positiveFilter.getFilter().isEmpty())
                        return ItemStack.EMPTY;
                    return stack;
                } else if (handler2 == null) {
                    ItemStack stack = handler1.getStackInSlot(slot);
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!negative) return ItemStack.EMPTY;
                    if (positive && !positiveFilter.getFilter().isEmpty() && negativeFilter.getFilter().isEmpty())
                        return ItemStack.EMPTY;
                    return stack;
                } else {
                    int size1 = handler1.getSlots();
                    ItemStack stack = slot < size1 ? handler1.getStackInSlot(slot) : handler2.getStackInSlot(slot - size1);
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!negative && !positive) return ItemStack.EMPTY;
                    if (negative && !positive && slot >= size1) return ItemStack.EMPTY;
                    if (positive && !negative && slot < size1) return ItemStack.EMPTY;
                    boolean negativeFilterEmpty = negativeFilter.getFilter().isEmpty();
                    boolean positiveFilterEmpty = positiveFilter.getFilter().isEmpty();
                    if (!negativeFilterEmpty || !positiveFilterEmpty) {
                        if (slot >= size1 && negative && positiveFilterEmpty) return ItemStack.EMPTY;
                        if (slot < size1 && positive && negativeFilterEmpty) return ItemStack.EMPTY;
                    }
                    return stack;
                }
            }, ItemStack.EMPTY);
        }

        @Override
        public @NotNull ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
            return preventRecursion(() -> {
                IItemHandler handler1 = getNegativeHandler();
                IItemHandler handler2 = getPositiveHandler();
                if (handler1 == null && handler2 == null) {
                    return stack;
                } else if (handler1 == null) {
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!positive) return stack;
                    if (negative && !negativeFilter.getFilter().isEmpty() && positiveFilter.getFilter().isEmpty())
                        return stack;
                    return handler2.insertItem(slot, stack, simulate);
                } else if (handler2 == null) {
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!negative) return stack;
                    if (positive && !positiveFilter.getFilter().isEmpty() && negativeFilter.getFilter().isEmpty())
                        return stack;
                    return handler1.insertItem(slot, stack, simulate);
                } else {
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    int size1 = handler1.getSlots();
                    if (!negative && !positive) return stack;
                    if (negative && !positive && slot >= size1) return stack;
                    if (positive && !negative && slot < size1) return stack;
                    boolean negativeFilterEmpty = negativeFilter.getFilter().isEmpty();
                    boolean positiveFilterEmpty = positiveFilter.getFilter().isEmpty();
                    if (!negativeFilterEmpty || !positiveFilterEmpty) {
                        if (slot >= size1 && negative && positiveFilterEmpty) return stack;
                        if (slot < size1 && positive && negativeFilterEmpty) return stack;
                    }
                    return slot < size1
                            ? handler1.insertItem(slot, stack, simulate)
                            : handler2.insertItem(slot - size1, stack, simulate);
                }
            }, stack);
        }

        @Override
        public @NotNull ItemStack extractItem(int slot, int amount, boolean simulate) {
            return preventRecursion(() -> {
                IItemHandler handler1 = getNegativeHandler();
                IItemHandler handler2 = getPositiveHandler();
                if (handler1 == null && handler2 == null) {
                    return ItemStack.EMPTY;
                } else if (handler1 == null) {
                    ItemStack stack = handler2.extractItem(slot, amount, true);
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!positive) return ItemStack.EMPTY;
                    if (negative && !negativeFilter.getFilter().isEmpty() && positiveFilter.getFilter().isEmpty())
                        return ItemStack.EMPTY;
                    return handler2.extractItem(slot, amount, simulate);
                } else if (handler2 == null) {
                    ItemStack stack = handler1.extractItem(slot, amount, true);
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!negative) return ItemStack.EMPTY;
                    if (positive && !positiveFilter.getFilter().isEmpty() && negativeFilter.getFilter().isEmpty())
                        return ItemStack.EMPTY;
                    return handler1.extractItem(slot, amount, simulate);
                } else {
                    int size1 = handler1.getSlots();
                    ItemStack stack = slot < size1 ? handler1.extractItem(slot, amount, true) : handler2.extractItem(slot - size1, amount, true);
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!negative && !positive) return ItemStack.EMPTY;
                    if (negative && !positive && slot >= size1) return ItemStack.EMPTY;
                    if (positive && !negative && slot < size1) return ItemStack.EMPTY;
                    boolean negativeFilterEmpty = negativeFilter.getFilter().isEmpty();
                    boolean positiveFilterEmpty = positiveFilter.getFilter().isEmpty();
                    if (!negativeFilterEmpty || !positiveFilterEmpty) {
                        if (slot >= size1 && negative && positiveFilterEmpty) return ItemStack.EMPTY;
                        if (slot < size1 && positive && negativeFilterEmpty) return ItemStack.EMPTY;
                    }
                    return slot < size1 ? handler1.extractItem(slot, amount, simulate) : handler2.extractItem(slot - size1, amount, simulate);
                }
            }, ItemStack.EMPTY);
        }

        @Override
        public int getSlotLimit(int slot) {
            return preventRecursion(() -> {
                IItemHandler handler1 = getNegativeHandler();
                IItemHandler handler2 = getPositiveHandler();
                if (handler1 == null && handler2 == null) {
                    return 0;
                } else if (handler1 == null) {
                    return handler2.getSlotLimit(slot);
                } else if (handler2 == null) {
                    return handler1.getSlotLimit(slot);
                } else {
                    int size1 = handler1.getSlots();
                    return slot < size1 ? handler1.getSlotLimit(slot) : handler2.getSlotLimit(slot - size1);
                }
            }, 0);
        }

        @Override
        public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            return preventRecursion(() -> {
                IItemHandler handler1 = getNegativeHandler();
                IItemHandler handler2 = getPositiveHandler();
                if (handler1 == null && handler2 == null) {
                    return false;
                } else if (handler1 == null) {
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!positive) return false;
                    if (negative && !negativeFilter.getFilter().isEmpty() && positiveFilter.getFilter().isEmpty())
                        return false;
                    return handler2.isItemValid(slot, stack);
                } else if (handler2 == null) {
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    if (!negative) return false;
                    if (positive && !positiveFilter.getFilter().isEmpty() && negativeFilter.getFilter().isEmpty())
                        return false;
                    return handler1.isItemValid(slot, stack);
                } else {
                    boolean negative = negativeFilter.test(stack);
                    boolean positive = positiveFilter.test(stack);
                    int size1 = handler1.getSlots();
                    if (!negative && !positive) return false;
                    if (negative && !positive && slot >= size1) return false;
                    if (positive && !negative && slot < size1) return false;
                    boolean negativeFilterEmpty = negativeFilter.getFilter().isEmpty();
                    boolean positiveFilterEmpty = positiveFilter.getFilter().isEmpty();
                    if (!negativeFilterEmpty || !positiveFilterEmpty) {
                        if (slot >= size1 && negative && positiveFilterEmpty) return false;
                        if (slot < size1 && positive && negativeFilterEmpty) return false;
                    }
                    return slot < size1
                            ? handler1.isItemValid(slot, stack)
                            : handler2.isItemValid(slot - size1, stack);
                }
            }, false);
        }
    }
}
