package com.hlysine.create_connected.content.brassgearbox;

import com.hlysine.create_connected.registries.CCBlockEntityTypes;
import com.hlysine.create_connected.registries.CCItems;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.phys.HitResult;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class BrassGearboxBlock extends RotatedPillarKineticBlock implements IBE<BrassGearboxBlockEntity> {

    public static final BooleanProperty FACE_1_FLIPPED = BooleanProperty.create("face_1_flipped");
    public static final BooleanProperty FACE_2_FLIPPED = BooleanProperty.create("face_2_flipped");
    public static final BooleanProperty FACE_3_FLIPPED = BooleanProperty.create("face_3_flipped");
    public static final BooleanProperty FACE_4_FLIPPED = BooleanProperty.create("face_4_flipped");

    public BrassGearboxBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.defaultBlockState()
                .setValue(FACE_1_FLIPPED, true)
                .setValue(FACE_2_FLIPPED, true)
                .setValue(FACE_3_FLIPPED, false)
                .setValue(FACE_4_FLIPPED, false)
        );
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(FACE_1_FLIPPED);
        builder.add(FACE_2_FLIPPED);
        builder.add(FACE_3_FLIPPED);
        builder.add(FACE_4_FLIPPED);
    }

    @Override
    public PushReaction getPistonPushReaction(BlockState state) {
        return PushReaction.PUSH_ONLY;
    }

    @SuppressWarnings("deprecation")
    @Override
    public @NotNull List<ItemStack> getDrops(BlockState state, @NotNull LootParams.Builder builder) {
        if (state.getValue(AXIS).isVertical())
            return super.getDrops(state, builder);
        return List.of(new ItemStack(CCItems.VERTICAL_BRASS_GEARBOX.get()));
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, LevelReader level, BlockPos pos, Player player) {
        if (state.getValue(AXIS).isVertical())
            return super.getCloneItemStack(state, target, level, pos, player);
        return new ItemStack(CCItems.VERTICAL_BRASS_GEARBOX.get());
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(AXIS, Axis.Y);
    }

    @Override
    public InteractionResult onWrenched(BlockState state, UseOnContext context) {
        if (state.getBlock() != this) return InteractionResult.PASS;
        int face = getFaceId(context.getClickedFace(), state.getValue(AXIS));
        if (face == 0) return InteractionResult.PASS;
        KineticBlockEntity.switchToBlockState(context.getLevel(), context.getClickedPos(), setFaceFlipped(face, state, !isFaceFlipped(face, state)));
        return InteractionResult.SUCCESS;
    }

    @Override
    protected boolean areStatesKineticallyEquivalent(BlockState oldState, BlockState newState) {
        if (!super.areStatesKineticallyEquivalent(oldState, newState)) return false;
        if (oldState.getValue(FACE_1_FLIPPED) != newState.getValue(FACE_1_FLIPPED)) return false;
        if (oldState.getValue(FACE_2_FLIPPED) != newState.getValue(FACE_2_FLIPPED)) return false;
        if (oldState.getValue(FACE_3_FLIPPED) != newState.getValue(FACE_3_FLIPPED)) return false;
        if (oldState.getValue(FACE_4_FLIPPED) != newState.getValue(FACE_4_FLIPPED)) return false;
        return true;
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        return face.getAxis() != state.getValue(AXIS);
    }

    @Override
    public Axis getRotationAxis(BlockState state) {
        return state.getValue(AXIS);
    }

    @Override
    public Class<BrassGearboxBlockEntity> getBlockEntityClass() {
        return BrassGearboxBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends BrassGearboxBlockEntity> getBlockEntityType() {
        return CCBlockEntityTypes.BRASS_GEARBOX.get();
    }

    @Override
    public @NotNull BlockState rotate(BlockState state, Rotation rot) {
        BlockState newState = super.rotate(state, rot);
        Axis axis = state.getValue(AXIS);
        Axis newAxis = newState.getValue(AXIS);

        // For each old face direction, determine its new face direction after rotation,
        // then carry the flip state over.
        List<Direction> directions = new ArrayList<>(DIRECTIONS);
        directions.removeIf(d -> d.getAxis() == axis);

        // Start with all flips false, then assign from old state
        boolean[] newFlips = new boolean[5]; // 1-indexed, [0] unused

        for (Direction oldDir : directions) {
            int oldFaceId = getFaceId(oldDir, axis);
            boolean flipped = isFaceFlipped(oldFaceId, state);

            Direction newDir = rot.rotate(oldDir);
            int newFaceId = getFaceId(newDir, newAxis);

            if (newFaceId != 0) {
                newFlips[newFaceId] = flipped;
            }
        }

        newState = newState
                .setValue(FACE_1_FLIPPED, newFlips[1])
                .setValue(FACE_2_FLIPPED, newFlips[2])
                .setValue(FACE_3_FLIPPED, newFlips[3])
                .setValue(FACE_4_FLIPPED, newFlips[4]);

        return newState;
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        BlockState newState = super.mirror(state, mirror);
        Axis axis = state.getValue(AXIS);
        Axis newAxis = newState.getValue(AXIS);

        List<Direction> directions = new ArrayList<>(DIRECTIONS);
        directions.removeIf(d -> d.getAxis() == axis);

        boolean[] newFlips = new boolean[5];

        for (Direction oldDir : directions) {
            int oldFaceId = getFaceId(oldDir, axis);
            boolean flipped = isFaceFlipped(oldFaceId, state);

            Direction newDir = mirror.mirror(oldDir);
            int newFaceId = getFaceId(newDir, newAxis);

            if (newFaceId != 0) {
                boolean mirrorReversesThisFace = axis == getMirrorAxis(mirror);
                newFlips[newFaceId] = flipped ^ mirrorReversesThisFace;
            }
        }

        return newState
                .setValue(FACE_1_FLIPPED, newFlips[1])
                .setValue(FACE_2_FLIPPED, newFlips[2])
                .setValue(FACE_3_FLIPPED, newFlips[3])
                .setValue(FACE_4_FLIPPED, newFlips[4]);
    }

    private static Axis getMirrorAxis(Mirror mirror) {
        return switch (mirror) {
            case LEFT_RIGHT -> Axis.Z;
            case FRONT_BACK -> Axis.X;
            default -> null; // Mirror.NONE
        };
    }

    private static final List<Direction> DIRECTIONS = Direction.stream().toList();

    public static int getFaceId(Direction face, Axis blockAxis) {
        List<Direction> directions = new ArrayList<>(DIRECTIONS);
        directions.removeIf(d -> d.getAxis() == blockAxis);
        return directions.indexOf(face) + 1;
    }

    public static boolean isFaceFlipped(int faceId, BlockState state) {
        return switch (faceId) {
            case 1 -> state.getValue(FACE_1_FLIPPED);
            case 2 -> state.getValue(FACE_2_FLIPPED);
            case 3 -> state.getValue(FACE_3_FLIPPED);
            case 4 -> state.getValue(FACE_4_FLIPPED);
            default -> false; // throw new IllegalStateException("Unexpected value: " + faceId);
            // cannot throw here, possibly due to mod incompatibility
        };
    }

    public static BlockState setFaceFlipped(int faceId, BlockState state, boolean flipped) {
        return switch (faceId) {
            case 1 -> state.setValue(FACE_1_FLIPPED, flipped);
            case 2 -> state.setValue(FACE_2_FLIPPED, flipped);
            case 3 -> state.setValue(FACE_3_FLIPPED, flipped);
            case 4 -> state.setValue(FACE_4_FLIPPED, flipped);
            default -> throw new IllegalStateException("Unexpected value: " + faceId);
        };
    }
}
